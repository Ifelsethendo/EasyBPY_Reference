import bpy
from  easybpy import * 

myObject = active_object()