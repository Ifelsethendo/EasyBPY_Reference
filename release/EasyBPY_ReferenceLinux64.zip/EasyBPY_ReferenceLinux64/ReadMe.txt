EasyBPY_Reference_v1 
Build: 12/13/2021

A reference tool for EasyBPY
https://curtisholt.online/easybpy
The app will look in the application directory for a folder with "easyBPY" in the name, and then look for easybpy.py to load and parse data.
If the file is not available it will ask you you to find it.

EasyBPY can be downloaded from: https://github.com/curtisjamesholt/EasyBPY
The included EasyBPY-master is current as of the date of this ReadMe


Once the app is open:
Filter field will filter function names for the typed text

Clicking:
First column list filters function names for the term selected

Second column list filters easybpy.py for the function definition

Top right button copies the function label and arguments to clipboard

Examples button pops up a menu that lists any files in the examples folder whose name contains the currently selected function 

The popup menu will load the selected example into the field below 

Save button will save changes to the example, or any new examples produced in the app

Wiki button will take you to https://github.com/curtisjamesholt/EasyBPY/wiki/


Included Editable Source File: EasyBPY_Reference.livecode
License: GPLv3

Made with LiveCode Community Edition 9.6.3 open source rapid application development environment available for Free at archive.org:

https://archive.org/search.php?query=creator%3A%22LiveCode%2C+Inc.%22

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT.